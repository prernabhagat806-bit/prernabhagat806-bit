# Prerna Bhagat — Portfolio Website

A responsive, single-page personal portfolio built with HTML, CSS and vanilla JavaScript.

## Run locally
1. Download and extract the ZIP.
2. Open the `prerna-portfolio` folder in VS Code.
3. Open `index.html` in a browser, or use the VS Code Live Server extension.

## Personalise
- Update the GitHub and Instagram profile URLs in `index.html` if needed.
- Add a profile photo or project links when you have final assets/URLs.
- Project cards currently describe the project ideas listed in the supplied profile; add verified implementation details as each project progresses.

## Deploy
You can publish this static site with GitHub Pages, Netlify, or Cloudflare Pages. For GitHub Pages, push these files to a repository and enable Pages in the repository's Settings.
